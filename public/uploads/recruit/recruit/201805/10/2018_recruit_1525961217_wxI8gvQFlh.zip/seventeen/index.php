<?php
/**
 * 这是 小众云 开发的一款新主题模板，如果想使用缩略图，请在文章自定义字段 img 添加网址即可。前台自动调用。底部的评论数量调用，在后台，设置，评论，侧边栏数量。评论部分，只写了列表的CSS，回复部分没有做，暂时先这样，后期会更新。星标日志，后台自定义字段 star 即可。
 * 
 * @package Typecho AK92 2017
 * @author Typecho Team
 * @version 2017.02.20
 * @link https://ak92.com/
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>


<section class="content-wrap">
        <div class="container">
            <div class="row">


                <main class="col-md-8 main-content">
               

<?php while($this->next()): ?>

<article id="<?php $this->cid() ?>" class="post">

    <?php if (array_key_exists('star',unserialize($this->___fields()))): ?><div class="featured" title="推荐文章">
        <i class="fa fa-star"></i>
    </div><?php endif; ?>

    <div class="post-head">
        <h1 class="post-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h1>
        <div class="post-meta">
            <span class="author">作者：<a href="<?php $this->author->permalink(); ?>"><?php $this->author(); ?></a></span> •
            <time class="post-date" datetime="<?php $this->date('c'); ?>" title="<?php $this->date('Y年m月d日'); ?>"><?php $this->date('Y年m月d日'); ?></time>
        </div>
    </div>
    <?php if (array_key_exists('img',unserialize($this->___fields()))): ?>
    <div class="featured-media">
        <a href="<?php $this->permalink() ?>"><img src="<?php $this->fields->img(); ?>" alt="<?php $this->title() ?>"></a>
    </div>
    <?php endif; ?>
    <div class="post-content">
        <?php $this->content(); ?>
    </div>
    <div class="post-permalink">
        <a href="<?php $this->permalink() ?>" class="btn btn-default">阅读全文</a>
    </div>

    <footer class="post-footer clearfix">
        <div class="pull-left tag-list">
            <i class="fa fa-folder-open-o"></i>
            <?php $this->tags(' , ', true, 'none'); ?>
        </div>
    </footer>
</article>

<?php endwhile; ?>

<nav class="pagination" role="navigation">
        
        <?php $this->pageLink('<x aria-label="Previous" class="newer-posts"><i class="fa fa-angle-left"></i></x>'); ?>
    <span class="page-number">第 <?php if($this->_currentPage>1) echo $this->_currentPage;  else echo 1;?> 页 / 共 <?php echo ceil($this->getTotal() / $this->parameter->pageSize); ?> 页</span>
        <?php $this->pageLink('<x aria-label="Next" class="older-posts"><i class="fa fa-angle-right"></i></x>','next'); ?>
</nav>


                </main>


<?php $this->need('sidebar.php'); ?>

            </div class="row">
        </div class="container">
</section>


<?php $this->need('footer.php'); ?>
