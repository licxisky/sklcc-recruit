<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

    <footer class="main-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="widget">
                        <h4 class="title">最新文章</h4>
                        <div class="content recent-post">
                        <?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=3')->to($contents); ?>
<?php while($contents->next()): ?>
                                <div class="recent-single-post">
                                    <a href="<?php $contents->permalink() ?>" class="post-title">
                                    <?php $contents->title() ?></a>
                                    <div class="date"><?php $contents->date('Y年m月d日') ?></div>
                                </div>
<?php endwhile; ?>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="widget">
                        <h4 class="title">最新评论</h4>
                        <div class="content recent-post">
            <?php $this->widget('Widget_Comments_Recent','ignoreAuthor=true')->to($comments); ?>
            <?php while ($comments->next()): ?>
                                <div class="recent-single-post">
                                    <a href="<?php $comments->permalink() ?>" class="post-title">
                                    <?php $comments->excerpt('40'); ?></a>
                                    <div class="date"><?php $comments->date('Y年m月d日') ?> # <?php $comments->author(false); ?></div>
                                </div> 
            <?php endwhile; ?>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="widget">
                        <h4 class="title">合作伙伴</h4>
                        <div class="content tag-cloud friend-links">
                            <a href="http://typecho.org" title="typecho官网"  target="_blank">Typecho官方网站</a>
                            <a href="https://typeho.me/" title="Typecho模板站" target="_blank">Typecho模板站</a>
                            <a href="https://plugins.typeho.me/" title="Typecho插件站" target="_blank">Typecho插件站</a>
                            <hr>
                            <a href="https://www.vpsmm.com/" title="小夜博客" target="_blank">小夜博客</a>
                            <a href="https://wiki.vpsmm.com/" title="小夜博客wiki教程" target="_blank">Linux使用教程</a>
                            <hr>
                            <a href="https://www.qianduanmei.com/" title="前端资讯网站" target="_blank">前端美</a>
                            <a href="https://bbs.vpsmm.com/" title="小夜博客交流论坛" target="_blank">小夜论坛</a>
                            <a href="https://app.typecho.me/" title="TYPECHO常用代码收集" target="_blank">Typecho代码</a>
                        </div>
                </div></div>
            </div>
        </div>
    </footer>

    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <span>Copyright &copy; <?php $this->options->title() ?></span> |
                    <span>模板设计：<a href="https://ak92.com/" target="_blank">小众云</a></span>
                </div>
            </div>
        </div>
    </div>

    <a href="#" id="back-to-top"><i class="fa fa-angle-up"></i></a>

    <script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
    <script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="<?php $this->options->themeUrl('js.js'); ?>"></script>

<?php $this->footer(); ?>
</body>
</html>
