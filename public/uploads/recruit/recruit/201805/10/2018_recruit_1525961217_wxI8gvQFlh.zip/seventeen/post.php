<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>



<section class="content-wrap">
        <div class="container">
            <div class="row">


                <main class="col-md-8 main-content">

    <article id="<?php $this->cid() ?>" class="post">

    <header class="post-head">
        <h1 class="post-title"><?php $this->title() ?></h1>
        <section class="post-meta">
            <span class="author">作者：<a itemprop="name" href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></span> •
            <time class="post-date" datetime="<?php $this->date('c'); ?>"><?php $this->date('Y年m月d日'); ?></time>
        </section>
    </header>


       <section class="post-content">
            <?php $this->content(); ?>

       </section>
        
    <footer class="post-footer clearfix">
        <div class="pull-left tag-list">
            <i class="fa fa-folder-open-o"></i>
            <?php $this->tags(' , ', true, 'none'); ?>
        </div>
    </footer>

    </article>

<div class="about-author clearfix">
    <?php $this->need('comments.php'); ?>
</div>

                </main>


<?php $this->need('sidebar.php'); ?>

            </div class="row">
        </div class="container">
</section>


<?php $this->need('footer.php'); ?>
