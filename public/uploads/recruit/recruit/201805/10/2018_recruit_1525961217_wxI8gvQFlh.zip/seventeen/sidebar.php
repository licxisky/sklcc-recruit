<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

               <aside class="col-md-4 sidebar">
                <!-- start widget -->
<!-- end widget --> 

<!-- start tag cloud widget -->
<div class="widget">
  <h4 class="title">搜索</h4>
  <div class="content community">
                <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
                    <label for="s" class="sr-only"><?php _e('搜索关键字'); ?></label>
                    <input type="text" name="s" class="text asearch" placeholder="<?php _e('输入关键字搜索'); ?>" />
                </form>
  </div>
</div>
<!-- end tag cloud widget --> 

<div class="widget">
  <h4 class="title">分类</h4>
  <div class="category">
  <?php $this->widget('Widget_Metas_Category_List')->listCategories('wrapClass=widget-list'); ?>
  </div>
</div>

<!-- start tag cloud widget -->
<div class="widget">
  <h4 class="title">标签云</h4>
  <div class="content tag-cloud">
    <?php $this->widget('Widget_Metas_Tag_Cloud', array('sort' => 'count', 'ignoreZeroCount' => true, 'desc' => true, 'limit' => 50))->to($tags); ?>  
<?php while($tags->next()): ?>  
<a rel="tag" href="<?php $tags->permalink(); ?>"><?php $tags->name(); ?></a>
<?php endwhile; ?>
  </div>
</div>
<!-- end tag cloud widget --> 

<!-- start widget -->
<!-- end widget --> 

<!-- start widget -->
<!-- end widget -->                </aside>
